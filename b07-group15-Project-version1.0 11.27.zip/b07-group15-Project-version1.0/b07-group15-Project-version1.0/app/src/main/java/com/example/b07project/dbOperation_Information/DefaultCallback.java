package com.example.b07project.dbOperation_Information;

public interface DefaultCallback {
    void onSuccess();
    void onFailure(Exception e);
}

