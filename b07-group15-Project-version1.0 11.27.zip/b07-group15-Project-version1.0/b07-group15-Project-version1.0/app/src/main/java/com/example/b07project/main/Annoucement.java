package com.example.b07project.main;

public class Annoucement extends Information {
    public Annoucement(){
        super();
    }

    public Annoucement(String subject, String content){
        super(subject, content);
    }
}
