package com.example.b07project.main;

import com.example.b07project.main.Information;

public class Complaint extends Information {
        public Complaint(){
            super();
        }

        public Complaint(String subject, String content){
            super(subject,content);
        }

    }

