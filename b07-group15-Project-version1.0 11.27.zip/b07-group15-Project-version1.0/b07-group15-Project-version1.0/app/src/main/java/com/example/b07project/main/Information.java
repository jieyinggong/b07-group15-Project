package com.example.b07project.main;

public class Information {
    public String infoID;
    public String subject;
    public String content;


    public Information(){}

    public Information(String subject, String content){
        this.subject = subject;
        this.content = content;
        infoID = "";
    }

}


