// daily stand up - google doc
https://docs.google.com/document/d/13z_PcgJZ_3P0xqsqr1IT8zUJG2KmI7cTe-3mX4wZusM/edit?usp=sharing
